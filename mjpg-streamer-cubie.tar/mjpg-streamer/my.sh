./mjpg_streamer -i "input_uvc"-o "output_http.so -w ./www"
