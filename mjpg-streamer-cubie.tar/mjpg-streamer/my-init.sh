sudo apt-get install libjpeg8-dev
sudo apt-get install imagemagick
make USE_LIBV4L2=true clean all
export LD_LIBRARY_PATH=.
