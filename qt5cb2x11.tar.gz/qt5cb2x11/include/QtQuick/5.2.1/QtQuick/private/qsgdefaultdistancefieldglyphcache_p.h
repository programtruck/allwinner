/****************************************************************************
**
** Copyright (C) 2013 Digia Plc and/or its subsidiary(-ies).
** Contact: http://www.qt-project.org/legal
**
** This file is part of the QtQuick module of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:LGPL$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and Digia.  For licensing terms and
** conditions see http://qt.digia.com/licensing.  For further information
** use the contact form at http://qt.digia.com/contact-us.
**
** GNU Lesser General Public License Usage
** Alternatively, this file may be used under the terms of the GNU Lesser
** General Public License version 2.1 as published by the Free Software
** Foundation and appearing in the file LICENSE.LGPL included in the
** packaging of this file.  Please review the following information to
** ensure the GNU Lesser General Public License version 2.1 requirements
** will be met: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.
**
** In addition, as a special exception, Digia gives you certain additional
** rights.  These rights are described in the Digia Qt LGPL Exception
** version 1.1, included in the file LGPL_EXCEPTION.txt in this package.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU
** General Public License version 3.0 as published by the Free Software
** Foundation and appearing in the file LICENSE.GPL included in the
** packaging of this file.  Please review the following information to
** ensure the GNU General Public License version 3.0 requirements will be
** met: http://www.gnu.org/copyleft/gpl.html.
**
**
** $QT_END_LICENSE$
**
****************************************************************************/

#ifndef QSGDEFAULTDISTANCEFIELDGLYPHCACHE_H
#define QSGDEFAULTDISTANCEFIELDGLYPHCACHE_H

#include "qsgadaptationlayer_p.h"
#include <QtGui/qopenglfunctions.h>
#include <qopenglshaderprogram.h>
#include <QtGui/private/qopenglengineshadersource_p.h>
#include <private/qsgareaallocator_p.h>

QT_BEGIN_NAMESPACE

class QOpenGLSharedResourceGuard;
#if !defined(QT_OPENGL_ES_2)
class QOpenGLFunctions_3_2_Core;
#endif

class Q_QUICK_PRIVATE_EXPORT QSGDefaultDistanceFieldGlyphCache : public QSGDistanceFieldGlyphCache
{
public:
    QSGDefaultDistanceFieldGlyphCache(QSGDistanceFieldGlyphCacheManager *man, QOpenGLContext *c, const QRawFont &font);
    virtual ~QSGDefaultDistanceFieldGlyphCache();

    void requestGlyphs(const QSet<glyph_t> &glyphs);
    void storeGlyphs(const QList<QDistanceField> &glyphs);
    void referenceGlyphs(const QSet<glyph_t> &glyphs);
    void releaseGlyphs(const QSet<glyph_t> &glyphs);

    bool useTextureResizeWorkaround() const;
    bool useTextureUploadWorkaround() const;
    int maxTextureSize() const;

    void setMaxTextureCount(int max) { m_maxTextureCount = max; }
    int maxTextureCount() const { return m_maxTextureCount; }

private:
    struct TextureInfo {
        GLuint texture;
        QSize size;
        QRect allocatedArea;
        QDistanceField image;

        TextureInfo() : texture(0)
        { }
    };

    void createTexture(TextureInfo * texInfo, int width, int height);
    void resizeTexture(TextureInfo * texInfo, int width, int height);

    TextureInfo *textureInfo(int index)
    {
        for (int i = m_textures.count(); i <= index; ++i)
            m_textures.append(TextureInfo());

        return &m_textures[index];
    }

    void createBlitProgram()
    {
        m_blitProgram = new QOpenGLShaderProgram;
        {
            QString source;
            source.append(QLatin1String(qopenglslMainWithTexCoordsVertexShader));
            source.append(QLatin1String(qopenglslUntransformedPositionVertexShader));

            QOpenGLShader *vertexShader = new QOpenGLShader(QOpenGLShader::Vertex, m_blitProgram);
            vertexShader->compileSourceCode(source);

            m_blitProgram->addShader(vertexShader);
        }
        {
            QString source;
            source.append(QLatin1String(qopenglslMainFragmentShader));
            source.append(QLatin1String(qopenglslImageSrcFragmentShader));

            QOpenGLShader *fragmentShader = new QOpenGLShader(QOpenGLShader::Fragment, m_blitProgram);
            fragmentShader->compileSourceCode(source);

            m_blitProgram->addShader(fragmentShader);
        }
        m_blitProgram->bindAttributeLocation("vertexCoordsArray", QT_VERTEX_COORDS_ATTR);
        m_blitProgram->bindAttributeLocation("textureCoordArray", QT_TEXTURE_COORDS_ATTR);
        m_blitProgram->link();
    }

    mutable int m_maxTextureSize;
    int m_maxTextureCount;

    QList<TextureInfo> m_textures;
    QHash<glyph_t, TextureInfo *> m_glyphsTexture;
    QSet<glyph_t> m_unusedGlyphs;

    QSGAreaAllocator *m_areaAllocator;

    QOpenGLShaderProgram *m_blitProgram;
    GLfloat m_blitVertexCoordinateArray[8];
    GLfloat m_blitTextureCoordinateArray[8];

    QOpenGLSharedResourceGuard *m_fboGuard;
#if !defined(QT_OPENGL_ES_2)
    QOpenGLFunctions_3_2_Core *m_funcs;
#endif
};

QT_END_NAMESPACE

#endif // QSGDEFAULTDISTANCEFIELDGLYPHCACHE_H
